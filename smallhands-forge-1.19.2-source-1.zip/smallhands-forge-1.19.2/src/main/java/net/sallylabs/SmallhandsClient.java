package net.sallylabs;

import net.minecraftforge.client.ConfigGuiHandler;
import net.minecraftforge.fml.ModLoadingContext;

public class SmallhandsClient {
	public static void init() {
		SmallhandsConfig.load();
		ModLoadingContext.get().registerExtensionPoint(
			ConfigGuiHandler.ConfigGuiFactory.class,
			() -> new ConfigGuiHandler.ConfigGuiFactory((mc, parent) -> new SmallhandsConfigScreen(parent))
		);
	}
}
