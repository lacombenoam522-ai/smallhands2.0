package net.sallylabs;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.gui.components.AbstractSliderButton;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.Locale;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class SmallhandsConfigScreen extends Screen {
	private final Screen parent;
	private final SmallhandsConfig.Data backup;

	public SmallhandsConfigScreen(Screen parent) {
		super(Component.literal("Smallhands"));
		this.parent = parent;
		SmallhandsConfig.Data c = SmallhandsConfig.get();
		this.backup = new SmallhandsConfig.Data();
		backup.scale = c.scale; backup.xOffset = c.xOffset; backup.yOffset = c.yOffset;
		backup.zOffset = c.zOffset; backup.affectItem = c.affectItem; backup.affectArm = c.affectArm;
	}

	@Override
	protected void init() {
		SmallhandsConfig.Data cfg = SmallhandsConfig.get();
		int w = 200, x = this.width / 2 - w / 2, y = this.height / 6;

		addRenderableWidget(new FloatSlider(x, y, w, 20, "Scale", 0.05f, 1.5f, 0.01f, cfg.scale, v -> cfg.scale = v));
		addRenderableWidget(new FloatSlider(x, y + 24, w, 20, "X Offset", -0.5f, 0.5f, 0.005f, cfg.xOffset, v -> cfg.xOffset = v));
		addRenderableWidget(new FloatSlider(x, y + 48, w, 20, "Y Offset", -0.5f, 0.5f, 0.005f, cfg.yOffset, v -> cfg.yOffset = v));
		addRenderableWidget(new FloatSlider(x, y + 72, w, 20, "Z Offset", -0.5f, 0.5f, 0.005f, cfg.zOffset, v -> cfg.zOffset = v));

		addRenderableWidget(toggle(x, y + 100, w, "Affect Item", () -> cfg.affectItem, b -> cfg.affectItem = b));
		addRenderableWidget(toggle(x, y + 124, w, "Affect Arm", () -> cfg.affectArm, b -> cfg.affectArm = b));

		addRenderableWidget(new Button(x, y + 156, w / 2 - 2, 20, Component.literal("Done"), b -> {
			SmallhandsConfig.save();
			this.minecraft.setScreen(parent);
		}));

		addRenderableWidget(new Button(x + w / 2 + 2, y + 156, w / 2 - 2, 20, Component.literal("Cancel"), b -> {
			SmallhandsConfig.set(backup);
			SmallhandsConfig.save();
			this.minecraft.setScreen(parent);
		}));
	}

	private Button toggle(int x, int y, int w, String label, Supplier<Boolean> get, Consumer<Boolean> set) {
		return new Button(x, y, w, 20, Component.literal(label + ": " + (get.get() ? "ON" : "OFF")), b -> {
			boolean nv = !get.get();
			set.accept(nv);
			b.setMessage(Component.literal(label + ": " + (nv ? "ON" : "OFF")));
		});
	}

	@Override
	public void render(PoseStack ps, int mouseX, int mouseY, float delta) {
		this.renderBackground(ps);
		drawCenteredString(ps, this.font, this.title, this.width / 2, 15, 0xFFFFFF);
		super.render(ps, mouseX, mouseY, delta);
	}

	@Override
	public void onClose() {
		this.minecraft.setScreen(parent);
	}

	private static class FloatSlider extends AbstractSliderButton {
		private final String label;
		private final float min, max, step;
		private final Consumer<Float> onChange;

		FloatSlider(int x, int y, int w, int h, String label, float min, float max, float step, float initial, Consumer<Float> onChange) {
			super(x, y, w, h, Component.empty(), (Math.max(min, Math.min(max, initial)) - min) / (max - min));
			this.label = label; this.min = min; this.max = max; this.step = step; this.onChange = onChange;
			updateMessage();
		}

		private float getFloatValue() {
			float raw = min + (float) this.value * (max - min);
			float snapped = Math.round(raw / step) * step;
			return Math.max(min, Math.min(max, snapped));
		}

		@Override
		protected void updateMessage() {
			setMessage(Component.literal(label + ": " + String.format(Locale.ROOT, "%.3f", getFloatValue())));
		}

		@Override
		protected void applyValue() {
			onChange.accept(getFloatValue());
		}
	}
}
