package net.sallylabs;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.minecraftforge.fml.loading.FMLPaths;

import java.io.*;

public class SmallhandsConfig {
	public static class Data {
		public float scale = 0.6f;
		public float xOffset = 0f;
		public float yOffset = 0f;
		public float zOffset = 0f;
		public boolean affectItem = true;
		public boolean affectArm = true;
	}

	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final File FILE = FMLPaths.CONFIGDIR.get().resolve("smallhands.json").toFile();
	private static Data DATA = new Data();

	public static Data get() { return DATA; }
	public static void set(Data d) { DATA = d; }

	public static void load() {
		if (!FILE.exists()) { save(); return; }
		try (Reader r = new BufferedReader(new FileReader(FILE))) {
			Data d = GSON.fromJson(r, Data.class);
			if (d != null) DATA = d;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void save() {
		try {
			FILE.getParentFile().mkdirs();
			try (Writer w = new BufferedWriter(new FileWriter(FILE))) {
				GSON.toJson(DATA, w);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
