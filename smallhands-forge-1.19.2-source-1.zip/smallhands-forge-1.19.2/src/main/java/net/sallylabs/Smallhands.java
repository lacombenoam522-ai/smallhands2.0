package net.sallylabs;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.fml.common.Mod;

@Mod("smallhands")
public class Smallhands {
	public Smallhands() {
		DistExecutor.safeRunWhenOn(Dist.CLIENT, () -> SmallhandsClient::init);
	}
}
