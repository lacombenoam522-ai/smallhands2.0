package net.sallylabs.mixin.client;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.ItemInHandRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.block.model.ItemTransforms;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.sallylabs.SmallhandsConfig;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemInHandRenderer.class)
public class HeldItemRendererMixin {

	@Unique
	private static void smallhands$apply(PoseStack poseStack) {
		SmallhandsConfig.Data cfg = SmallhandsConfig.get();
		poseStack.pushPose();
		poseStack.translate(cfg.xOffset, cfg.yOffset, cfg.zOffset);
		poseStack.scale(cfg.scale, cfg.scale, cfg.scale);
	}

	@Inject(method = "renderItem", at = @At("HEAD"))
	private void smallhands$preRenderItem(LivingEntity entity, ItemStack stack, ItemTransforms.TransformType type,
			boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int light, CallbackInfo ci) {
		if (SmallhandsConfig.get().affectItem) smallhands$apply(poseStack);
		else poseStack.pushPose();
	}

	@Inject(method = "renderItem", at = @At("RETURN"))
	private void smallhands$postRenderItem(LivingEntity entity, ItemStack stack, ItemTransforms.TransformType type,
			boolean leftHand, PoseStack poseStack, MultiBufferSource buffer, int light, CallbackInfo ci) {
		poseStack.popPose();
	}

	@Inject(method = "renderPlayerArm", at = @At("HEAD"))
	private void smallhands$preRenderArm(PoseStack poseStack, MultiBufferSource buffer, int light,
			float equipProgress, float swingProgress, HumanoidArm arm, CallbackInfo ci) {
		if (SmallhandsConfig.get().affectArm) smallhands$apply(poseStack);
		else poseStack.pushPose();
	}

	@Inject(method = "renderPlayerArm", at = @At("RETURN"))
	private void smallhands$postRenderArm(PoseStack poseStack, MultiBufferSource buffer, int light,
			float equipProgress, float swingProgress, HumanoidArm arm, CallbackInfo ci) {
		poseStack.popPose();
	}
}
