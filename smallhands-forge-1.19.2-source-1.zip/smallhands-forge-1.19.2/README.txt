Smallhands - Forge 1.19.2 (Forge 43.x, Java 17)
Build : gradle 7.6.x puis  gradle build
Jar    : build/libs/smallhands-1.0.0+forge-1.19.2.jar  (a mettre dans le dossier mods)
